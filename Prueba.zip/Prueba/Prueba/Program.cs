﻿using System;
using System.Collections.Generic;
using System.Linq;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;

namespace Prueba
{
    class Program
    {
        static void Main(string[] args)
        {
 

            /* open de navegador whit dirver Chrone*/
            IWebDriver driver = new ChromeDriver(@"C:\Users\gromerom\Desktop\belatrix\src\test\resources\drivers");
            driver.Navigate().GoToUrl("https://www.ebay.com/");
            driver.Manage().Window.Maximize();

            driver.FindElement(By.XPath("//*[@id=\"mainContent\"]/div[1]/ul/li[4]/a")).Click();
            driver.FindElement(By.XPath("//span[contains(text(),'Zapatos')]")).Click();
            driver.FindElement(By.XPath("//li[@id='w2-w0-w2']//ul[@class='b-accordion-subtree']//li//a[@class='b-textlink b-textlink--sibling'][contains(text(),'Zapatos de hombre')]")).Click();
            driver.FindElement(By.XPath("//div[contains(text(),'PUMA')]")).Click();
            driver.FindElement(By.XPath("//div[@id='w2-w1-w0-multiselect[0]']//a[@class='cbx x-refine__multi-select-link']")).Click();

            /*print result */
            string numero = driver.FindElement(By.XPath("//h2[@class='srp-controls__count-heading'] ")).Text;
            Console.WriteLine("Resultado ***" + numero + "***" );

            /*order by descending */
            driver.FindElement(By.XPath("//div[@id='w8-w0-w1']//button[@class='x-flyout__button']")).Click();
            driver.FindElement(By.XPath("//div[contains(@class,'srp-controls--selected-value')] ")).Click();
            driver.FindElement(By.XPath("//span[contains(text(),'Precio + Envío: más alto primero')]")).Click();

            /* prinmt 5 firts prodcts */

            try { 
            string art1 = driver.FindElement(By.XPath("//h3[contains(text(),'Zapato Bota Zapatillas Puma En Gamuza Cuero Gamuza')]")).Text;
            Console.WriteLine("Result 1 ***" + art1 + "***");
            string art2 = driver.FindElement(By.XPath("//h3[contains(text(),'Puma scarpa scarpetta sneakers in pelle scamosciat')]")).Text;
            Console.WriteLine("Resultado 2 ***" + art2 + "***");
            string art3 = driver.FindElement(By.XPath("//h3[contains(text(),'Puma Chaussures Griffe Sneakers Cuir Daim Rose Suè')]")).Text;
            Console.WriteLine("Resultado 3 ***" + art3 + "***");
            string art4 = driver.FindElement(By.XPath("//h3[contains(text(),'Puma zapato zapato de cuero sneakers serraje Pink ')]")).Text;
            Console.WriteLine("Resultado 4 ***" + art4 + "***");
            string art5 = driver.FindElement(By.XPath("//h3[contains(text(),'Puma Zapato Shoe Sneakers Gamuza Cuero Rosa Gamuza')]")).Text;
            Console.WriteLine("Resultado 5 ***" + art5 + "***");
            }
            catch(Exception e)
            {
                Console.WriteLine("error in  " + e.Message);
            }


        }
    }


}
